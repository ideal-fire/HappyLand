3dsx (homebrew launcher) users, copy the 3ds directory to the root of your sd.

If you're using the cia version, you still need to copy /3ds/data/HappyLand.
It's where the game's resources are stored.